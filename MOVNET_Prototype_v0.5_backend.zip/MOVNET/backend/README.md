# MOVNET API — этап 1: аккаунты и права доступа

Реализован рабочий каркас API на FastAPI + PostgreSQL:
- регистрация и вход по email/паролю;
- Argon2id-хеширование паролей;
- короткоживущий JWT access token;
- профиль `/me`;
- серверный статус подписки `/entitlements`;
- одноразовое погашение кода `/codes/redeem` (в БД хранится SHA-256-хеш, повторное использование запрещено);
- endpoint `/payments/create` намеренно возвращает 501, пока не подключён настоящий провайдер.

## Локальный запуск через Docker
1. Установить Docker Desktop.
2. В этой папке скопировать `.env.example` в `.env`.
3. В `.env` задать уникальный `JWT_SECRET` (не менее 32 случайных байт), пароль БД в `DATABASE_URL` и `POSTGRES_PASSWORD` для compose.
4. Запустить `docker compose up --build`.
5. Открыть `http://localhost:8000/docs` и проверить `/health`, `/auth/register`, `/auth/login`, `/me` и `/entitlements`.

Пример `DATABASE_URL`:
`postgresql+psycopg://movnet:ВАШ_ПАРОЛЬ@db:5432/movnet`

## Важно перед публикацией
- Это первый backend-этап, а не production-релиз: нужны миграции Alembic, rate limiting, email verification, refresh-token rotation, аудит безопасности, HTTPS reverse proxy и резервные копии.
- Не публикуйте `.env`, JWT_SECRET, пароли, bot token или ключи провайдера в APK/Git.
- Коды активации создаются доверенным администратором/платёжным webhook. В приложении нет публичного endpoint для выпуска кодов.
- Реальная оплата не включена; Premium не активируется по скриншоту, сообщению или клиентскому флагу.
- Для PostgreSQL `FOR UPDATE` блокирует строку кода во время погашения. Перед запуском миграции и нагрузочные тесты обязательны.
