from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Generator

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pwdlib import PasswordHash
from pydantic import BaseModel, EmailStr, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker


class Settings(BaseSettings):
    database_url: str = "sqlite:///./movnet.db"
    jwt_secret: str = "DEV_ONLY_CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT"
    jwt_issuer: str = "movnet-api"
    access_token_minutes: int = 30
    cors_origins: str = "http://localhost:3000"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
if settings.jwt_secret == "DEV_ONLY_CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT":
    print("WARNING: using development JWT secret; set JWT_SECRET before deployment")

connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
password_hash = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(512))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    entitlement: Mapped["Entitlement | None"] = relationship(back_populates="user", uselist=False)


class Entitlement(Base):
    __tablename__ = "entitlements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True, index=True)
    plan: Mapped[str] = mapped_column(String(80))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    user: Mapped[User] = relationship(back_populates="entitlement")


class RedeemCode(Base):
    __tablename__ = "redeem_codes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    plan: Mapped[str] = mapped_column(String(80))
    duration_days: Mapped[int] = mapped_column(Integer)
    redeemed: Mapped[bool] = mapped_column(Boolean, default=False)
    redeemed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    redeemed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


Base.metadata.create_all(bind=engine)
app = FastAPI(title="MOVNET API", version="0.1.0", description="Account and entitlement API prototype")
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class RedeemRequest(BaseModel):
    code: str = Field(min_length=12, max_length=128)


def db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def issue_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": str(user.id), "iss": settings.jwt_issuer, "iat": now, "exp": now + timedelta(minutes=settings.access_token_minutes)}
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(db_session)) -> User:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Bearer token required")
    try:
        payload = jwt.decode(credentials.credentials, settings.jwt_secret, algorithms=["HS256"], issuer=settings.jwt_issuer)
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=401, detail="Account not found")
    return user


@app.get("/health")
def health():
    return {"status": "ok", "service": "movnet-api"}


@app.post("/auth/register", status_code=201)
def register(body: RegisterRequest, db: Session = Depends(db_session)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(email=email, password_hash=password_hash.hash(body.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": issue_token(user), "token_type": "bearer", "expires_in": settings.access_token_minutes * 60}


@app.post("/auth/login")
def login(body: LoginRequest, db: Session = Depends(db_session)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if user is None or not password_hash.verify(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return {"access_token": issue_token(user), "token_type": "bearer", "expires_in": settings.access_token_minutes * 60}


@app.get("/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "email": user.email, "created_at": user.created_at}


@app.get("/entitlements")
def entitlements(user: User = Depends(current_user), db: Session = Depends(db_session)):
    item = db.scalar(select(Entitlement).where(Entitlement.user_id == user.id))
    active = bool(item and item.expires_at > datetime.now(timezone.utc))
    return {"active": active, "plan": item.plan if active else None, "expires_at": item.expires_at if active else None}


def digest_code(raw_code: str) -> str:
    return hashlib.sha256(raw_code.strip().upper().encode("utf-8")).hexdigest()


@app.post("/codes/redeem")
def redeem(body: RedeemRequest, user: User = Depends(current_user), db: Session = Depends(db_session)):
    # Codes are stored only as SHA-256 digests and redeemed in one DB transaction.
    code = db.scalar(select(RedeemCode).where(RedeemCode.code_hash == digest_code(body.code)).with_for_update())
    if code is None or code.redeemed:
        raise HTTPException(status_code=400, detail="Code is invalid or already used")
    now = datetime.now(timezone.utc)
    existing = db.scalar(select(Entitlement).where(Entitlement.user_id == user.id).with_for_update())
    start = existing.expires_at if existing and existing.expires_at > now else now
    expiry = start + timedelta(days=code.duration_days)
    if existing:
        existing.plan, existing.expires_at = code.plan, expiry
    else:
        db.add(Entitlement(user_id=user.id, plan=code.plan, expires_at=expiry))
    code.redeemed, code.redeemed_by, code.redeemed_at = True, user.id, now
    db.commit()
    return {"active": True, "plan": code.plan, "expires_at": expiry}


@app.post("/payments/create", status_code=501)
def create_payment(user: User = Depends(current_user)):
    # Intentionally disabled until a real provider and verified webhook are configured.
    raise HTTPException(status_code=501, detail="Payments are not configured. No payment was created and no subscription was activated.")


# Helper for local development only. Never expose this as a public endpoint.
def create_dev_code(db: Session, plan: str, duration_days: int) -> str:
    raw = secrets.token_urlsafe(18).upper()
    db.add(RedeemCode(code_hash=digest_code(raw), plan=plan, duration_days=duration_days))
    db.commit()
    return raw
