# MOVNET API — аккаунты и серверный каталог

FastAPI + PostgreSQL backend. Реализованы:
- регистрация `/auth/register` и вход `/auth/login` по email/паролю;
- Argon2id-хеширование паролей, JWT access token;
- профиль `/me` и подписка `/entitlements`;
- публичный серверный каталог `GET /catalog` и `GET /catalog/{id}`;
- управление каталогом администратором: `POST /admin/catalog`, `PUT /admin/catalog/{id}`, `DELETE /admin/catalog/{id}` через заголовок `X-Admin-Key` (удаление скрывает карточку);
- одноразовые коды подписки `/codes/redeem`.

Первый запуск автоматически добавляет 10 демонстрационных карточек в таблицу `catalog_items`. Это только метаданные-примеры: реальные фильмы, постеры, серии и лицензированные видеопотоки нужно добавить отдельно. В текущем Android-плеере остаётся тестовый ролик, сервер пока не раздаёт реальные видео.

## Развёртывание API

1. Разверните backend на сервере/VPS с Docker и доменом.
2. В папке `backend` скопируйте `.env.example` в `.env`.
3. Установите уникальные значения `POSTGRES_PASSWORD`, `DATABASE_URL`, `JWT_SECRET` (случайная строка не менее 32 байт) и `ADMIN_API_KEY`.
4. Укажите публичный HTTPS-домен в `CORS_ORIGINS` при необходимости.
5. Выполните `docker compose up --build -d`.
6. Проверьте `https://ВАШ-ДОМЕН/health` и `https://ВАШ-ДОМЕН/docs`.

Не публикуйте `.env`, JWT_SECRET и ADMIN_API_KEY в GitHub или APK. Перед production нужны миграции Alembic, rate limiting, подтверждение email, refresh-token rotation, резервное копирование, аудит и HTTPS reverse proxy.

## Добавление карточки в каталог

`POST /admin/catalog` с заголовком `X-Admin-Key: <ADMIN_API_KEY>` и JSON:

```json
{
  "title": "Название",
  "genre": "Драма",
  "year": "2026",
  "premium": false,
  "emoji": "🎬",
  "description": "Описание контента",
  "content_type": "Фильмы",
  "meta": "1 ч 40 мин",
  "stream_url": null,
  "published": true
}
```

Если передаётся `stream_url`, допускается только HTTPS. Добавляйте только контент, права на который принадлежат вам или предоставлены по лицензии. Сейчас приложение получает карточки с `GET /catalog`; адрес потока в Android-плеер ещё не подключён.

## Android: подключение к вашему серверу

В GitHub откройте **Settings → Secrets and variables → Actions → Variables → New repository variable**. Создайте переменную:

- Name: `MOVNET_API_BASE_URL`
- Value: `https://api.ВАШ-ДОМЕН` (без завершающего `/`)

После этого workflow соберёт APK с этим адресом. Локально можно передать Gradle property `-PMOVNET_API_BASE_URL=https://api.ВАШ-ДОМЕН`.

Если переменная не задана, APK соберётся, но сетевые функции покажут понятное сообщение о необходимости настройки HTTPS API.
